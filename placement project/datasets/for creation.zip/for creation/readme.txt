For generating the dataset, what we have done is the made a code( by chatgpt) AND in it we have the filled the data requried for the dataset and than made the random rows by help of it, We have made the different .ipynb file for different type of the data, And than we will execute each of the .ipynb file for making the .csv file for each of the subject

Than after running the each .ipynb file we will run the main.ipynb file which will combine and shuffle each of the .csv file and will give us the shuffeled_data.csv file

And our work is our


Happy hacking!! - Neel Shah