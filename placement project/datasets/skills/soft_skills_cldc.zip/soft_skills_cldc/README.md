# soft_skills
Skills and clusters results used for soft skills analysis
